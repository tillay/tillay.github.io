#!/bin/bash

MULLVAD_STATUS=$(mullvad status)

if [[ $MULLVAD_STATUS == *"Connected"* ]]; then
    echo "/home/$USER/.config/waybar/vpn-connected.png"
elif [[ $MULLVAD_STATUS == *"Blocked"* ]]; then
    echo "/home/$USER/.config/waybar/vpn-blocked.png"
elif [[ $MULLVAD_STATUS == *"Connecting"* ]]; then
    echo "/home/$USER/.config/waybar/vpn-blocked.png"
elif [[ $MULLVAD_STATUS == *"Disconnected"* ]]; then
    echo "/home/$USER/.config/waybar/vpn-disconnected.png"
fi
